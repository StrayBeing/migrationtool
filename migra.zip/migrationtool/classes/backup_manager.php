<?php

namespace local_migrationtool;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot.'/backup/util/includes/backup_includes.php');

class backup_manager {

    public function export_course($courseid, $mode) {

        global $USER, $CFG;

        $bc = new \backup_controller(
            \backup::TYPE_1COURSE,
            $courseid,
            \backup::FORMAT_MOODLE,
            \backup::INTERACTIVE_NO,
            \backup::MODE_GENERAL,
            $USER->id
        );

        $bc->execute_plan();

        $results = $bc->get_results();
$file = $results['backup_destination'];

$filename = $file->get_filename();

$targetdir = $CFG->dataroot.'/migrationtool/backups/';

if (!is_dir($targetdir)) {
    mkdir($targetdir, 0775, true);
}

$targetpath = $targetdir.$filename;

file_put_contents($targetpath, $file->get_content());

return $targetpath;
    }

}
