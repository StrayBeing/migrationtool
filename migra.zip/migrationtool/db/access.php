<?php

$capabilities = [];
